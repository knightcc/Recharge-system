
#ifndef __CAMERA__
#define __CAMERA__


//显示一张jpeg的图片
int show_jpg(char *filename,int X,int Y);

//显示一张jpeg的图片到显存
int show_jpg_fbmem(char *filename,int X,int Y,unsigned long *fb_mem);

//显示一帧jpeg的数据到显存
int show_jpegdata_fbmem(char * jpegdata, int size,int X,int Y, unsigned long *fb_mem);

//抓拍生成一张jpg图片
int take_photo(const char *picname);

//开始捕捉帧数据
int take_jpgdata_init();

//采集一帧jpg数据
int take_jpg(char *jpgdata);

//结束捕捉帧数据
void  take_jpgdata_uninit();




#endif  //__CAMERA__
