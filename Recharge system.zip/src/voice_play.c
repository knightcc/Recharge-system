#include "voice_play.h"

char *Num[] = {"0.mp3","1.mp3","2.mp3","3.mp3","4.mp3","5.mp3","6.mp3","7.mp3","8.mp3", "9.mp3"};


/*播放数字*/ // 1234 ==> 1 千  2 百 3 十 4
void num_play(int num,int play_flag)
{
	char cmd[64] = {0};
	if(num == 0)
	{
		system("madplay ../sound/0.mp3");
	}
	else	//计算这个数字的每一位
	{
		if(num / 1000 > 0)	//千位不为0
		{
			//播放num的千位 --> 计算千位
			sprintf(cmd, "madplay ../sound/%s", Num[(num/1000)%10]);
			system(cmd);		//播放千位数字
			if(1 == play_flag)system("madplay ../sound/1000.mp3");
		}
		if(num / 100 > 0)	//百位不为0
		{
			//播放num的百位 --> 计算百位
			sprintf(cmd, "madplay ../sound/%s", Num[(num/100)%10]);
			system(cmd);		//播放千位数字
			if(1 == play_flag)system("madplay ../sound/100.mp3");			
		}
		if(num / 10 > 0)	//十位不为0
		{
			//播放num的百位 --> 计算十位
			sprintf(cmd, "madplay ../sound/%s", Num[(num/10)%10]);
			system(cmd);		//播放千位数字
			if(1 == play_flag)system("madplay ../sound/10.mp3");			
		}
		if(num %10 > 0)		//个位不为0
		{
			//播放num的百位 --> 计算个位
			sprintf(cmd, "madplay ../sound/%s", Num[num%10]);
			system(cmd);		//播放千位数字			
		}	
		if(num %10 == 0 && 0 == play_flag)system("madplay ../sound/0.mp3");		
		
	}
}

/*将时间times以 "xx小时xx分xx秒" 的格式播放语音信息*/
void time_play(int times)	//4000秒 = 1小时6分40秒
{
	int hour, minute, second;	//计算times秒等于 xx小时xx分钟xx秒
	
	hour = times / 3600;			//计算小时数
	minute = (times%3600)/60;		//计算分钟数
	second = times % 60;			//计算秒数
	
	//播放 xx 小时
	num_play(hour,1);		//播放小时数
	system("madplay ../sound/shi.mp3");		//小时
	
	//播放 xx 分钟
	num_play(minute,1);	//播放分钟数
	system("madplay ../sound/fen.mp3");		//分
	
	//播放 xx 秒
	num_play(second,1);
	system("madplay ../sound/miao.mp3");		//秒
}


/*将缴费金额money以 "您此次的停车费用为XX元" 的格式播放语音信息*/
void money_play(int money)
{
	system("madplay ../sound/feiyong.mp3");	//您此次的停车费用为
	num_play(money,1);
	system("madplay ../sound/yuan.mp3");	//元
}

